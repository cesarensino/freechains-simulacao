timestamp=1704666209463

num_with_dot="${timestamp:0:10}.${timestamp:10}"
echo "Número com ponto: $num_with_dot"
date -d @$num_with_dot +"%d/%m/%Y %H:%M:%S.%3N" -d "+15 days" 

#data=$(date -d "@$timestamp" +"+%Y-%m-%d_%H:%M:%S.%3N")

echo $data

#data_nova=$(date -d "$data +15 days" +%s.%3N)

#$data | cut -d '.' -f 1

timestamp=$(date -d "$data" +%s%3N)

echo "$timestamp" 

num_with_dot="${timestamp:0:10}.${timestamp:10}"
echo "Número com ponto: $num_with_dot"
date -d @$num_with_dot +"%d/%m/%Y %H:%M:%S.%3N" -d "+15 days" 

#data=$(date -d "@$timestamp" +"+%Y-%m-%d_%H:%M:%S.%3N")

echo $data
