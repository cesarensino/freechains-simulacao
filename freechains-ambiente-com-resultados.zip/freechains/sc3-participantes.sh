#!/bin/bash

echo -e "\033[0;31mInclusão de outros participantes e repasse da primeira mensagem\033[0m"
sleep 5

#cpio=$(sed -n '1p' /tmp/freechains/user1/cpub1.txt)
cpiopub=$(sed -n '1p' /tmp/freechains/user1/cpub1.txt)

for j in 2 3 4 5

do
#	freechains --host=localhost:833$j chains join '#sala_de_estudos_1' $cpiopub
	freechains --host=localhost:833$j chains join '#sala_de_estudos_1' $cpiopub 
	echo -e "\\033[0;33m Usuário user$j entrou no chat público \\033[0m"
	sleep 3
	freechains --host=localhost:833$j peer localhost:8331 recv '#sala_de_estudos_1'
	echo -e "\\033[0;33m Usuário user$j recebeu chat \\033[0m"
	
done 
