#!/bin/bash

clear

echo "**********************INÍCIO DE UM NOVO FÓRUM******************************"
sleep 5

echo -e "\033[0;31mCriação do chat e a primeira mensagem\033[0m"
sleep 5

# Coletando as chaves do peer 1 
cpio=$(sed -n '1p' /tmp/freechains/user1/cpub1.txt)
cpiopvt=$(cat /tmp/freechains/user1/cpvt1.txt)

echo -e "\\033[0;33m Comando de criação do chat e guarda do Hash da Sala \\033[0m"
freechains --host=localhost:8331 chains join '#sala_de_estudos_1' "$cpio" > hsala.txt
sleep 2

echo -e "\\033[0;33m Criando a primeira mensagem através da leitura do texto de um arquivo \\033[0m"
# coletando a primeira linha do arquivo de bate-papo
linha=$(sed -n '1p' /tmp/freechains/conversa.txt)
# armazenamento do hash do envio da primeira mensagem ao chat
freechains --host=localhost:8331 chain '#sala_de_estudos_1' post inline "$linha" --sign=$(echo $cpiopvt) > hpost1.txt
sleep 2

echo -e "\\033[0;33m Hash do Bloco Genesis \\033[0m"
#conferindo genesis
freechains --port=8331 chain '#sala_de_estudos_1' genesis
# echo $cpiopvt
