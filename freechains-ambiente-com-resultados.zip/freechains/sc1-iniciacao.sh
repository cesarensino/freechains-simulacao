#!/bin/bash

clear
echo "*****************INÍCIO DA SIMULAÇÃO DO EXERCÍCIO DE CONVERSAS NO FREECHAINS*******************************"
sleep 5

echo -e "\033[0;31m PARTE 1 - Criação de pastas dos usuarios, inicio de hosts locais, geração e guarda de chaves publicas e privadas\033[0m"

sleep 5

# criação de 5 peers iniciais
for i in 1 2 3 4 5

do
	mkdir user$i
	sleep 2
	freechains-host --port=833$i start /tmp/freechains/user$i/ &
	sleep 2
	freechains --host=localhost:833$i keys pubpvt "Minha frase-passe $i" > /tmp/freechains/chaves$i.txt
	sleep 2
        read cpub cpvt < /tmp/freechains/chaves$i.txt
        echo $cpub > /tmp/freechains/user$i/cpub$i.txt
        echo $cpvt > /tmp/freechains/user$i/cpvt$i.txt
        #exibição das chaves para fins de conferência da simulação
        echo -e "\\033[0;33m Criação do user$i com cpub $cpub e cpvt $cpvt \\033[0m"
done

sleep 5

clear

echo "**********************INÍCIO DE UM NOVO FÓRUM******************************"
sleep 5

echo -e "\033[0;31m PARTE 2 - Criação do chat e a primeira mensagem\033[0m"
sleep 5

# Coletando as chaves do peer 1 
cpio=$(sed -n '1p' /tmp/freechains/user1/cpub1.txt)
cpiopvt=$(cat /tmp/freechains/user1/cpvt1.txt)

echo -e "\\033[0;33m Comando de criação do chat e guarda do Hash da Sala \\033[0m"
freechains --host=localhost:8331 chains join '#sala_de_estudos_1' "$cpio" > hsala.txt
sleep 2

echo -e "\\033[0;33m Criando a primeira mensagem através da leitura do texto de um arquivo \\033[0m"
# coletando a primeira linha do arquivo de bate-papo
linha=$(sed -n '1p' /tmp/freechains/conversa.txt)
# armazenamento do hash do envio da primeira mensagem ao chat
freechains --host=localhost:8331 chain '#sala_de_estudos_1' post inline "$linha" --sign=$(echo $cpiopvt) > hpost1.txt
sleep 2

echo -e "\\033[0;33m Hash do Bloco Genesis \\033[0m"
#conferindo genesis
freechains --port=8331 chain '#sala_de_estudos_1' genesis
# echo $cpiopvt

sleep 5

clear 
echo -e "\033[0;31m PARTE 3 - Inclusão de outros participantes e repasse da primeira mensagem\033[0m"
sleep 3

#cpio=$(sed -n '1p' /tmp/freechains/user1/cpub1.txt)
cpiopub=$(sed -n '1p' /tmp/freechains/user1/cpub1.txt)

for j in 2 3 4 5

do
#	freechains --host=localhost:833$j chains join '#sala_de_estudos_1' $cpiopub
	freechains --host=localhost:833$j chains join '#sala_de_estudos_1' $cpiopub 
	echo -e "\\033[0;33m Usuário user$j entrou no chat público \\033[0m"
	sleep 3
	freechains --host=localhost:833$j peer localhost:8331 recv '#sala_de_estudos_1'
	echo -e "\\033[0;33m Usuário user$j recebeu chat \\033[0m"
	
done

sleep 1








